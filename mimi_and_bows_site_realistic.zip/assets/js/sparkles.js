// same sparkles as before (keeps sparkle canvas and cursor)
(function(){
  const canvas = document.getElementById('sparkle-canvas');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  let w=canvas.width=innerWidth, h=canvas.height=innerHeight;
  const particles = [];
  function onResize(){ w=canvas.width=innerWidth; h=canvas.height=innerHeight; }
  addEventListener('resize', onResize);
  for(let i=0;i<60;i++){
    particles.push({ x: Math.random()*w, y: Math.random()*h, r: 1+Math.random()*2, vx: (Math.random()-0.5)*0.2, vy: (Math.random()-0.5)*0.2, life: 200+Math.random()*400, max: 200+Math.random()*400 });
  }
  let mouse = {x:-9999,y:-9999};
  addEventListener('mousemove', function(e){ mouse.x = e.clientX; mouse.y = e.clientY;
    for(let i=0;i<3;i++){ particles.push({ x: mouse.x + (Math.random()-0.5)*10, y: mouse.y + (Math.random()-0.5)*10, r: 1+Math.random()*2, vx: (Math.random()-0.5)*2, vy: (Math.random()-0.5)*2 - 1, life: 30+Math.random()*40, max: 30+Math.random()*40 }); }
  });
  addEventListener('click', function(e){ for(let i=0;i<12;i++){ particles.push({ x: e.clientX + (Math.random()-0.5)*30, y: e.clientY + (Math.random()-0.5)*30, r: 1+Math.random()*3, vx: (Math.random()-0.5)*4, vy: (Math.random()-0.5)*4, life: 40+Math.random()*60, max: 40+Math.random()*60 }); } });
  function loop(){ ctx.clearRect(0,0,w,h);
    for(let i=particles.length-1;i>=0;i--){ const p = particles[i]; p.x += p.vx; p.y += p.vy; p.life--; if(p.max>400){ p.x += Math.sin(Date.now()/10000 + i)*0.1; } const alpha = Math.max(0, Math.min(1, p.life / p.max)); ctx.beginPath(); ctx.fillStyle = 'rgba(255,170,220,'+alpha+')'; ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill(); if(p.life<=0) particles.splice(i,1); }
    while(particles.length<60){ particles.push({ x: Math.random()*w, y: Math.random()*h, r: 1+Math.random()*2, vx: (Math.random()-0.5)*0.2, vy: (Math.random()-0.5)*0.2, life: 200+Math.random()*400, max: 200+Math.random()*400 }); }
    requestAnimationFrame(loop);
  }
  loop();
  const cursor = document.createElement('div');
  cursor.style.position='fixed'; cursor.style.width='10px'; cursor.style.height='10px'; cursor.style.borderRadius='50%'; cursor.style.pointerEvents='none'; cursor.style.zIndex='9999'; cursor.style.transform='translate(-50%,-50%)'; cursor.style.boxShadow='0 0 10px rgba(255,122,182,0.9)'; cursor.style.background='rgba(255,122,182,0.9)';
  document.body.appendChild(cursor);
  addEventListener('mousemove', e=>{ cursor.style.left = e.clientX+'px'; cursor.style.top = e.clientY+'px'; });
})();