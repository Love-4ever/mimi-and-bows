// main.js — improved: uses Unsplash for realistic jewelry images, product modal, nicer cards
(function(){
  const CART_KEY = 'mimi_cart_v1';
  function getCart(){ try{ return JSON.parse(localStorage.getItem(CART_KEY) || '[]'); }catch(e){ return []; } }
  function saveCart(cart){ localStorage.setItem(CART_KEY, JSON.stringify(cart)); updateCartCount(); }
  function updateCartCount(){ const count = getCart().reduce((s,i)=>s+i.qty,0); document.querySelectorAll('#cart-count').forEach(el=>el.textContent = count); }

  // generate products (120) -- images from Unsplash for more realistic look
  function generateProducts(areaId, count=120){
    const grid = document.getElementById(areaId);
    if(!grid) return;
    for(let i=1;i<=count;i++){
      const img = `https://source.unsplash.com/400x400/?jewelry,bow&sig=${i}`;
      const price = (Math.floor(Math.random()*45)+7).toFixed(2);
      const id = 'p'+i;
      const div = document.createElement('div');
      div.className = 'card';
      div.innerHTML = `
        <img loading="lazy" src="${img}" alt="Jewelry ${i}">
        <div class="meta">
          <h4>Lovely Jewel #${i}</h4>
          <div class="small">Silver plated • Cute charm</div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div class="price">$${price}</div>
            <div>
              <button class="btn" data-id="${id}" data-name="Lovely Jewel #${i}" data-price="${price}" data-img="${img}" data-action="add">Add</button>
              <button class="btn" data-id="${id}" data-img="${img}" data-action="view">View</button>
            </div>
          </div>
        </div>
      `;
      grid.appendChild(div);
    }
  }

  // preview: show a few items on homepage
  function generatePreview(){
    const grid = document.getElementById('preview-grid');
    if(!grid) return;
    generateProducts('preview-grid', 6);
  }

  function setupDelegation(){
    document.body.addEventListener('click', function(e){
      const btn = e.target.closest('button[data-action]');
      if(!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      if(action==='add'){
        const name = btn.dataset.name; const price = parseFloat(btn.dataset.price); const img = btn.dataset.img;
        const cart = getCart(); const found = cart.find(x=>x.id===id);
        if(found) found.qty += 1; else cart.push({id,name,price,qty:1,img});
        saveCart(cart);
        btn.textContent = 'Added ✓';
        setTimeout(()=>btn.textContent = 'Add',900);
      }
      if(action==='view'){
        const img = btn.dataset.img; const title = btn.dataset.name || 'Product'; const price = btn.dataset.price || '';
        openModal({img,title,price});
      }
    });
  }

  // modal
  function openModal(data){
    const modal = document.getElementById('product-modal');
    if(!modal) return;
    modal.querySelector('#modal-img').src = data.img;
    modal.querySelector('#modal-title').textContent = data.title;
    modal.querySelector('#modal-price').textContent = data.price ? '$'+data.price : '';
    modal.querySelector('#modal-desc').textContent = 'A delicate handmade piece. Add a note to your order at checkout.';
    modal.querySelector('#modal-add').onclick = function(){
      const id = 'p' + Math.floor(Math.random()*100000);
      const cart = getCart(); cart.push({id,data,name:data.title,price:parseFloat(data.price||0)||9.99,qty:1,img:data.img}); saveCart(cart);
      modal.setAttribute('aria-hidden','true');
    };
    modal.setAttribute('aria-hidden','false');
  }
  function closeModal(){ const modal = document.getElementById('product-modal'); if(modal) modal.setAttribute('aria-hidden','true'); }

  function setupModalEvents(){
    document.addEventListener('click', function(e){
      if(e.target.matches('.modal-close')) closeModal();
      if(e.target.matches('#product-modal')) closeModal();
    });
  }

  // music loader
  function setupMusic(){
    const music = document.getElementById('bg-music');
    if(!music) return;
    music.src = music.dataset.src || 'assets/audio/lofi.mp3';
    music.volume = 0.22;
  }

  document.addEventListener('DOMContentLoaded', function(){
    generateProducts('product-grid', 120);
    generatePreview();
    updateCartCount();
    setupDelegation();
    setupModalEvents();
    setupMusic();
  });

  window.MimiBows = { getCart, saveCart };
})();