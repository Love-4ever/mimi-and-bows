// same cart.js adjusted to keep compatibility with new product ids
(function(){
  function getCart(){ try{ return JSON.parse(localStorage.getItem('mimi_cart_v1') || '[]'); }catch(e){ return []; } }
  function render(){
    const container = document.getElementById('cart-contents');
    if(!container) return;
    const cart = getCart();
    if(cart.length===0){
      container.innerHTML = '<p>Your cart is empty. Go to <a href="shop.html">shop</a> and add some sparkles ✨</p>';
      document.getElementById('cart-input').value = '';
      return;
    }
    let html = ''; let total = 0;
    cart.forEach(item=>{
      total += item.price * item.qty;
      html += `<div class="line">
        <img src="${item.img}" style="width:72px;height:72px;object-fit:cover;border-radius:8px">
        <div style="flex:1"><div><strong>${item.name||item.data||'Item'}</strong></div>
          <div class="small">$${item.price} × <span class="qty">${item.qty}</span></div></div>
        <div style="min-width:110px;text-align:right"><div class="price">$${(item.price*item.qty).toFixed(2)}</div>
          <div style="margin-top:8px">
            <button class="btn" data-id="${item.id}" data-action="dec">-</button>
            <button class="btn" data-id="${item.id}" data-action="inc">+</button>
            <button class="btn" data-id="${item.id}" data-action="rm">Remove</button>
          </div></div></div>`;
    });
    html += `<div style="padding-top:12px"><strong>Total: $${total.toFixed(2)}</strong></div>`;
    container.innerHTML = html;
    document.getElementById('cart-input').value = JSON.stringify(cart);
    container.querySelectorAll('button[data-action]').forEach(btn=>{
      btn.addEventListener('click', function(){
        const id = this.dataset.id; const action = this.dataset.action;
        const cart = getCart(); const idx = cart.findIndex(x=>x.id===id);
        if(idx<0) return;
        if(action==='inc') cart[idx].qty++;
        if(action==='dec') cart[idx].qty = Math.max(1, cart[idx].qty-1);
        if(action==='rm') cart.splice(idx,1);
        localStorage.setItem('mimi_cart_v1', JSON.stringify(cart));
        render();
        document.querySelectorAll('#cart-count').forEach(el=> el.textContent = JSON.parse(localStorage.getItem('mimi_cart_v1')||'[]').reduce((s,i)=>s+i.qty,0) );
      });
    });
  }
  document.addEventListener('DOMContentLoaded', render);
})();